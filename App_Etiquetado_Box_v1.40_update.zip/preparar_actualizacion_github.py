from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


DEFAULT_GITHUB_OWNER = "irodriguezfino"
DEFAULT_GITHUB_REPO = "app-etiquetado-box-updates"
DEFAULT_REPO_DIR = Path("github-updates")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def normalize_notes(notes: str) -> str:
    lines = [line.strip() for line in notes.replace("\\n", "\n").splitlines()]
    return "\n".join(line for line in lines if line)


def build_manifest(version: str, package_file: str, digest: str, notes: str, owner: str, repo: str) -> dict:
    package_url = f"https://raw.githubusercontent.com/{owner}/{repo}/main/{package_file}"
    published_at = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    return {
        "schema": "app-etiquetado-box-update-v1",
        "version": version,
        "published_at": published_at,
        "auto_update": {
            "type": "zip",
            "file": package_file,
            "url": package_url,
            "sha256": digest,
        },
        "notes": notes,
        "package_type": "zip",
        "package": package_file,
        "package_url": package_url,
        "sha256": digest,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepara el repo de GitHub para una nueva actualizacion.")
    parser.add_argument("version", help="Version publicada, por ejemplo 1.41")
    parser.add_argument("zip", type=Path, help="ZIP de actualizacion")
    parser.add_argument("--notes", required=True, help="Notas visibles para el usuario")
    parser.add_argument("--repo-dir", type=Path, default=DEFAULT_REPO_DIR, help="Carpeta local del repo de updates")
    parser.add_argument("--owner", default=DEFAULT_GITHUB_OWNER, help="Usuario u organizacion de GitHub")
    parser.add_argument("--repo", default=DEFAULT_GITHUB_REPO, help="Nombre del repo de GitHub")
    args = parser.parse_args()

    source_zip = args.zip.resolve()
    if not source_zip.exists():
        raise FileNotFoundError(source_zip)

    repo_dir = args.repo_dir
    repo_dir.mkdir(parents=True, exist_ok=True)

    package_name = f"App_Etiquetado_Box_v{args.version}_update.zip"
    package_path = repo_dir / package_name
    shutil.copy2(source_zip, package_path)

    digest = sha256(package_path)
    notes = normalize_notes(args.notes)
    manifest = build_manifest(args.version, package_name, digest, notes, args.owner, args.repo)

    (repo_dir / "version.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (repo_dir / f"CHANGELOG_v{args.version}.txt").write_text(notes + "\n", encoding="utf-8")

    print(f"Actualizacion preparada: {package_path}")
    print(f"SHA256: {digest}")
    print(f"Manifiesto: {repo_dir / 'version.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
