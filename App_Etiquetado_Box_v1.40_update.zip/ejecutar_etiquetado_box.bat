@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 app_etiquetado_box.py
    goto :fin
)

where python >nul 2>nul
if %errorlevel%==0 (
    python app_etiquetado_box.py
    goto :fin
)

echo No se ha encontrado Python en este equipo.
echo Instala Python 3 y las dependencias con: pip install -r requirements.txt
pause

:fin
endlocal
