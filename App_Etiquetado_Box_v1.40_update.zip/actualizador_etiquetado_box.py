from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path
from tkinter import messagebox


APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "update_config.json"
DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/irodriguezfino/app-etiquetado-box-updates/main/version.json"


def _version_key(value: str) -> tuple[int, ...]:
    parts = [int(part) for part in re.findall(r"\d+", str(value))]
    return tuple(parts or [0])


def _read_update_config() -> dict:
    config = {
        "enabled": True,
        "manifest_url": DEFAULT_MANIFEST_URL,
    }
    if CONFIG_PATH.exists():
        try:
            loaded = json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))
            if isinstance(loaded, dict):
                config.update(loaded)
        except Exception:
            pass
    return config


def _fetch_json(url: str) -> dict:
    request = urllib.request.Request(url, headers={"User-Agent": "EtiquetadoBoxUpdater/1.0"})
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8-sig"))


def _manifest_package(manifest: dict) -> tuple[str, str, str]:
    auto_update = manifest.get("auto_update") if isinstance(manifest.get("auto_update"), dict) else {}
    package_url = manifest.get("package_url") or auto_update.get("url")
    package_name = manifest.get("package") or auto_update.get("file") or "actualizacion.zip"
    sha256 = manifest.get("sha256") or auto_update.get("sha256")
    if not package_url or not sha256:
        raise ValueError("El manifiesto remoto no contiene package_url/url y sha256.")
    return str(package_url), str(package_name), str(sha256)


def _download_file(url: str, target: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "EtiquetadoBoxUpdater/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response, target.open("wb") as output:
        while True:
            chunk = response.read(1024 * 256)
            if not chunk:
                break
            output.write(chunk)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _write_powershell_updater() -> Path:
    script = r'''
param(
    [Parameter(Mandatory=$true)][string]$AppDir,
    [Parameter(Mandatory=$true)][string]$ZipPath,
    [Parameter(Mandatory=$true)][int]$ParentPid,
    [Parameter(Mandatory=$true)][string]$RestartExe,
    [string]$RestartArgs = ""
)

$ErrorActionPreference = "Stop"

try {
    Wait-Process -Id $ParentPid -Timeout 60
} catch {
}

Start-Sleep -Seconds 1

$Stage = Join-Path ([System.IO.Path]::GetTempPath()) ("etiquetado_box_update_" + [System.Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $Stage -Force | Out-Null
Expand-Archive -LiteralPath $ZipPath -DestinationPath $Stage -Force

$Source = $Stage
$Children = @(Get-ChildItem -LiteralPath $Stage -Force)
if ($Children.Count -eq 1 -and $Children[0].PSIsContainer) {
    $Source = $Children[0].FullName
}

$Preserve = @("config_usuario.json", "exportaciones")
foreach ($Item in Get-ChildItem -LiteralPath $Source -Force) {
    if ($Preserve -contains $Item.Name) {
        continue
    }
    Copy-Item -LiteralPath $Item.FullName -Destination $AppDir -Recurse -Force
}

Remove-Item -LiteralPath $Stage -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 1
if (Test-Path -LiteralPath $RestartExe) {
    if ($RestartArgs) {
        Start-Process -FilePath $RestartExe -ArgumentList $RestartArgs -WorkingDirectory $AppDir
    } else {
        Start-Process -FilePath $RestartExe -WorkingDirectory $AppDir
    }
}
'''
    target = Path(tempfile.gettempdir()) / "aplicar_actualizacion_etiquetado_box.ps1"
    target.write_text(script.strip() + "\n", encoding="utf-8")
    return target


def _restart_command() -> tuple[str, str]:
    if getattr(sys, "frozen", False):
        return sys.executable, ""
    return sys.executable, str(Path(__file__).resolve().with_name("app_etiquetado_box.py"))


def _launch_update(zip_path: Path, root) -> None:
    restart_exe, restart_args = _restart_command()
    script = _write_powershell_updater()
    subprocess.Popen(
        [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script),
            "-AppDir",
            str(APP_DIR),
            "-ZipPath",
            str(zip_path),
            "-ParentPid",
            str(os.getpid()),
            "-RestartExe",
            restart_exe,
            "-RestartArgs",
            restart_args,
        ],
        close_fds=True,
    )
    root.destroy()


def _ask_and_download(root, current_version: str, manifest: dict, status_var) -> None:
    remote_version = str(manifest.get("version", "")).strip()
    notes = str(manifest.get("notes", "")).strip()
    text = f"Hay una nueva version disponible: {remote_version}\n\nVersion instalada: {current_version}"
    if notes:
        text += f"\n\nCambios:\n{notes}"
    text += "\n\nQuieres descargarla e instalarla ahora?"

    if not messagebox.askyesno("Actualizacion disponible", text, parent=root):
        if status_var is not None:
            status_var.set("Actualizacion pospuesta.")
        return

    if status_var is not None:
        status_var.set("Descargando actualizacion...")

    def worker() -> None:
        try:
            package_url, package_name, expected_sha = _manifest_package(manifest)
            target = Path(tempfile.gettempdir()) / package_name
            _download_file(package_url, target)
            actual_sha = _sha256(target)
            if actual_sha != expected_sha.upper():
                raise ValueError("La verificacion SHA256 no coincide. Se cancela la actualizacion.")

            def ready() -> None:
                if status_var is not None:
                    status_var.set("Actualizacion descargada y verificada.")
                if messagebox.askyesno(
                    "Aplicar actualizacion",
                    "La aplicacion se cerrara, aplicara la actualizacion y volvera a abrirse.",
                    parent=root,
                ):
                    _launch_update(target, root)
                elif status_var is not None:
                    status_var.set("Actualizacion descargada, pendiente de aplicar.")

            root.after(0, ready)
        except Exception as exc:
            root.after(0, lambda: _show_update_error(root, status_var, exc))

    threading.Thread(target=worker, daemon=True).start()


def _show_update_error(root, status_var, exc: Exception) -> None:
    if status_var is not None:
        status_var.set("No se pudo completar la actualizacion.")
    messagebox.showwarning("Actualizacion no disponible", str(exc), parent=root)


def check_for_updates_async(root, current_version: str, status_var=None) -> None:
    config = _read_update_config()
    if not config.get("enabled", True):
        return
    manifest_url = str(config.get("manifest_url") or DEFAULT_MANIFEST_URL).strip()
    if not manifest_url:
        return

    def worker() -> None:
        try:
            manifest = _fetch_json(manifest_url)
            remote_version = str(manifest.get("version", "")).strip()
            if remote_version and _version_key(remote_version) > _version_key(current_version):
                root.after(0, lambda: _ask_and_download(root, current_version, manifest, status_var))
        except Exception:
            # El arranque de trabajo no debe molestarse si no hay red o GitHub no responde.
            return

    threading.Thread(target=worker, daemon=True).start()
