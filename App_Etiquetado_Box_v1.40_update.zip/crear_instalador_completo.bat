@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "APP_NAME=Etiquetado_Box_Salazon"
set "APP_VERSION=1.40"
set "PROJECT_ROOT=%CD%"
set "INSTALLER_DIR=%PROJECT_ROOT%\instalador"
set "UPDATE_PACKAGE_ZIP=%INSTALLER_DIR%\App_Etiquetado_Box_v%APP_VERSION%_update.zip"
set "USB_PACKAGE_DIR=%INSTALLER_DIR%\Paquete_USB_Etiquetado_Box_Salazon_v%APP_VERSION%"
set "USB_PACKAGE_ZIP=%INSTALLER_DIR%\Paquete_USB_Etiquetado_Box_Salazon_v%APP_VERSION%.zip"
set "ICON_PATH=assets\ICONO_SUITE_RRHH.ico"
set "ISS_SCRIPT=instalador_etiquetado_box.iss"
set "TARGET_INSTALL_BAT=instalar_en_equipo_destino.bat"

echo.
echo ============================================================
echo  CREAR INSTALADOR COMPLETO - ETIQUETADO BOX SALAZON
echo ============================================================
echo.

if not exist "%ICON_PATH%" (
    echo ERROR: No se encuentra el icono "%ICON_PATH%".
    pause
    exit /b 1
)

if not exist "config\articulos.txt" (
    echo ERROR: No se encuentra config\articulos.txt.
    pause
    exit /b 1
)

call :find_python
if not defined PY_CMD (
    echo ERROR: No se ha encontrado Python 3 en este equipo.
    echo Instala Python 3 y vuelve a ejecutar este BAT.
    pause
    exit /b 1
)

echo Python detectado:
%PY_CMD% --version
echo.

echo Comprobando dependencias de ejecucion...
%PY_CMD% -c "import PIL, win32print, win32ui" >nul 2>nul
if errorlevel 1 (
    echo Instalando dependencias de ejecucion desde requirements.txt...
    %PY_CMD% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo ERROR: No se pudieron instalar las dependencias de ejecucion.
        pause
        exit /b 1
    )
) else (
    echo Dependencias de ejecucion OK.
)

echo.
echo Comprobando PyInstaller...
%PY_CMD% -c "import PyInstaller" >nul 2>nul
if errorlevel 1 (
    echo Instalando PyInstaller...
    %PY_CMD% -m pip install pyinstaller
    if errorlevel 1 (
        echo ERROR: No se pudo instalar PyInstaller.
        pause
        exit /b 1
    )
) else (
    echo PyInstaller OK.
)

echo.
echo Limpiando compilaciones anteriores...
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "%APP_NAME%.spec" del /q "%APP_NAME%.spec"
if not exist "%INSTALLER_DIR%" mkdir "%INSTALLER_DIR%"

echo.
echo Generando ejecutable con PyInstaller...
%PY_CMD% -m PyInstaller ^
    --noconfirm ^
    --clean ^
    --noconsole ^
    --onedir ^
    --name "%APP_NAME%" ^
    --icon "%ICON_PATH%" ^
    --add-data "assets;assets" ^
    --add-data "config;config" ^
    --hidden-import win32print ^
    --hidden-import win32con ^
    --hidden-import win32ui ^
    --hidden-import PIL.ImageWin ^
    app_etiquetado_box.py

if errorlevel 1 (
    echo ERROR: PyInstaller no pudo generar el ejecutable.
    pause
    exit /b 1
)

if not exist "dist\%APP_NAME%\%APP_NAME%.exe" (
    echo ERROR: No se ha generado dist\%APP_NAME%\%APP_NAME%.exe.
    pause
    exit /b 1
)

if exist "update_config.json" copy /y "update_config.json" "dist\%APP_NAME%\update_config.json" >nul

echo.
echo Preparando ZIP de actualizacion automatica...
if exist "%UPDATE_PACKAGE_ZIP%" del /q "%UPDATE_PACKAGE_ZIP%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'dist\%APP_NAME%\*' -DestinationPath '%UPDATE_PACKAGE_ZIP%' -Force"
if errorlevel 1 (
    echo ERROR: No se pudo crear el ZIP de actualizacion automatica.
    pause
    exit /b 1
)
echo ZIP de actualizacion creado:
echo "%UPDATE_PACKAGE_ZIP%"

echo.
echo Preparando paquete USB instalable sin Inno Setup...
if exist "%USB_PACKAGE_DIR%" rmdir /s /q "%USB_PACKAGE_DIR%"
if exist "%USB_PACKAGE_ZIP%" del /q "%USB_PACKAGE_ZIP%"
mkdir "%USB_PACKAGE_DIR%"
robocopy "dist\%APP_NAME%" "%USB_PACKAGE_DIR%\%APP_NAME%" /MIR /NFL /NDL /NJH /NJS /NP
if errorlevel 8 (
    echo ERROR: No se pudo preparar la carpeta de aplicacion para USB.
    pause
    exit /b 1
)
copy /y "%TARGET_INSTALL_BAT%" "%USB_PACKAGE_DIR%\%TARGET_INSTALL_BAT%" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%USB_PACKAGE_DIR%\*' -DestinationPath '%USB_PACKAGE_ZIP%' -Force"
if errorlevel 1 (
    echo AVISO: No se pudo comprimir el paquete USB, pero la carpeta esta creada.
) else (
    echo Paquete USB creado:
    echo "%USB_PACKAGE_ZIP%"
)

call :find_inno
if not defined ISCC_EXE (
    echo.
    echo AVISO: No se ha encontrado Inno Setup Compiler ^(ISCC.exe^) en este equipo.
    echo No se genera el instalador .exe clasico de Inno Setup.
    echo.
    echo Ya tienes un paquete USB instalable sin Inno Setup en:
    echo "%USB_PACKAGE_ZIP%"
    echo.
    echo En el ordenador nuevo, descomprime ese ZIP y ejecuta como administrador:
    echo "%TARGET_INSTALL_BAT%"
    pause
    exit /b 0
)

echo.
echo Inno Setup detectado:
echo "%ISCC_EXE%"
echo.
echo Generando instalador completo...
"%ISCC_EXE%" /DMyAppVersion="%APP_VERSION%" "%ISS_SCRIPT%"
if errorlevel 1 (
    echo ERROR: Inno Setup no pudo generar el instalador.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  INSTALADOR GENERADO CORRECTAMENTE
echo ============================================================
echo.
echo Carpeta:
echo "%INSTALLER_DIR%"
echo.
echo Archivo esperado:
echo "%INSTALLER_DIR%\Instalador_Etiquetado_Box_Salazon_v%APP_VERSION%.exe"
echo.
echo Tambien se ha creado un paquete USB alternativo:
echo "%USB_PACKAGE_ZIP%"
echo.
echo Copia el .exe de Inno o el ZIP USB a un pincho y usalo en el ordenador nuevo.
echo En el ordenador nuevo NO hace falta instalar Python, PyInstaller ni Inno Setup.
echo.
pause
exit /b 0

:find_python
set "PY_CMD="
if exist "%LocalAppData%\Python\bin\python.exe" set "PY_CMD="%LocalAppData%\Python\bin\python.exe""
if defined PY_CMD exit /b 0

for /f "delims=" %%P in ('where python 2^>nul') do (
    if not defined PY_CMD set "PY_CMD="%%P""
)
if defined PY_CMD exit /b 0

where py >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3"
exit /b 0

:find_inno
set "ISCC_EXE="
for %%P in (
    "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
    "%ProgramFiles%\Inno Setup 6\ISCC.exe"
    "%ProgramFiles(x86)%\Inno Setup 5\ISCC.exe"
    "%ProgramFiles%\Inno Setup 5\ISCC.exe"
) do (
    if exist "%%~P" set "ISCC_EXE=%%~P"
)
if defined ISCC_EXE exit /b 0

for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do (
    if not defined ISCC_EXE set "ISCC_EXE=%%I"
)
exit /b 0
