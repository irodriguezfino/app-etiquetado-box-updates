#define MyAppName "Etiquetado Box Salazon"
#ifndef MyAppVersion
#define MyAppVersion "1.40"
#endif
#define MyAppPublisher "Rodriguez - Finura"
#define MyAppExeName "Etiquetado_Box_Salazon.exe"
#define MyDistDir SourcePath + "\dist\Etiquetado_Box_Salazon"
#define MyOutputDir SourcePath + "\instalador"

[Setup]
AppId={{2D509A57-C95E-4B03-85D1-6C8373D4D2A6}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppVerName={#MyAppName} v{#MyAppVersion}
DefaultDirName={autopf}\Etiquetado Box Salazon
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir={#MyOutputDir}
OutputBaseFilename=Instalador_Etiquetado_Box_Salazon_v{#MyAppVersion}
SetupIconFile={#SourcePath}\assets\ICONO_SUITE_RRHH.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear acceso directo en el escritorio"; GroupDescription: "Accesos directos:"; Flags: checkedonce

[Dirs]
Name: "{app}"; Permissions: users-modify
Name: "{app}\exportaciones"; Permissions: users-modify
Name: "{app}\config"; Permissions: users-modify

[Files]
Source: "{#MyDistDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#SourcePath}\config\*"; DestDir: "{app}\config"; Flags: ignoreversion recursesubdirs createallsubdirs onlyifdoesntexist

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{commondesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir {#MyAppName}"; Flags: nowait postinstall skipifsilent
