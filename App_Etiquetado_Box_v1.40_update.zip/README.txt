﻿APLICACION ETIQUETADO BOX - SALAZON

Entrada:
- Fichero .txt de partida separado por punto y coma.
- El lote se toma del nombre del fichero.
- El articulo se lee de la cuarta columna.
- El peso se lee de la ultima columna con valor numerico.

Configuracion para informatica:
- config/articulos.txt: leyenda codigo articulo -> descripcion.
- config/config_salazon.csv: codigo articulo; nombre con rango de peso; dias en sal por defecto.
- config/festivos.json: festivos adicionales o excepciones.

Uso:
1. Ejecutar app_etiquetado_box.py.
2. Seleccionar la partida .txt.
3. Introducir fecha de entrada, elegir rango de peso del desplegable, revisar dias en sal, unidades por box y etiquetas por box.
4. Pulsar Generar vista previa.
5. Revisar boxes y pulsar Imprimir etiquetas.

Impresion:
- Pensada para una Citizen CL-S703 instalada como impresora Windows.
- Tamano de etiqueta: 162 x 111 mm.
- Si pywin32 no esta disponible, la app permite guardar la etiqueta como PNG para pruebas.
- En una instalacion, preferencias, configuracion editable y exportaciones se guardan dentro de la carpeta instalada en Program Files.

Cambios v1.1:
- Etiqueta vertical en blanco y negro.
- Titulo HOJA DE SALAZON.
- Muestra fecha de recepcion leida del TXT, lote numerico de 6 digitos, total de piezas en rango y articulo con codigo.
- Las exportaciones manuales se proponen en la carpeta exportaciones de la aplicacion.


Cambios v1.2:
- Etiqueta mas compacta, con menos margen y mucho menos espacio en blanco.
- Tipografias ampliadas para mejorar lectura en operativa de sala.
- Pie de box mas visible y lineas de separacion reposicionadas para ocupar mejor la altura.


Cambios v1.3:
- Fecha de recepcion y fecha de entrada colocadas en una misma linea horizontal.
- Piezas en rango y unidades por box colocadas en una misma linea horizontal.
- Leyendas de datos mas grandes y valores ampliados con el espacio ganado.


Cambios v1.4:
- Selector grafico de calendario para la fecha de entrada.
- Botones + y - para dias en sal, unidades por box y etiquetas por box.
- Rueda del raton enlazada al scroll vertical de la pantalla principal.


Cambios v1.5:
- Botones principales, calendario, controles + / - y cierre de detalles redibujados con componentes Canvas.
- Barra de pasos superior sustituida por una barra Canvas limpia con estilo de suite.
- Se mantiene la logica y entradas nativas donde prima la edicion fiable de datos.


Cambios v1.6:
- Resumen operativo superior con jamones, boxes, etiquetas, fecha de salida y estado de validacion.
- Validacion visual en vivo al cambiar fichero, fechas, dias, pesos, unidades o copias.
- Botones + y - tambien para peso minimo y peso maximo.
- Accion directa Generar + imprimir para operativa rapida con confirmacion previa.
- Navegacion anterior/siguiente entre etiquetas desde la vista previa.
- La tabla resalta el ultimo box cuando queda como resto.
- El calendario marca fecha de entrada, salida calculada y fines de semana.
- Panel de impresora compactado como zona de configuracion.


Cambios v1.7:
- Recuadros principales redibujados con paneles Canvas, bordes redondeados, sombra suave y acento visual de suite.
- Barra secuencial superior refinada con numeros mas grandes, circulos mejor proporcionados y linea de progreso mas clara.
- Eliminado el boton y la accion interna Generar + imprimir para evitar impresiones demasiado directas.


Cambios v1.8:
- Validaciones adicionales sobre la partida: extension TXT, fichero vacio, lineas no validas, lote corto, articulos sin leyenda y recepciones/articulos multiples.
- La aplicacion recuerda la ultima eleccion de unidades por box y etiquetas por box; los dias en sal arrancan siempre a 0.
- Disposicion adaptable: en ventanas estrechas la vista previa baja debajo de los datos para mantener legibles los controles.
- La vista previa tiene altura estable y miniatura contenida para que el bloque de toma de datos no se desplace al generar.


Cambios v1.9:
- Corregido el borde inferior de los paneles Canvas dejando un margen inferior fijo para que el contenido interno no tape el marco.
- Refuerzo visual inferior suave en los bloques para que el cierre del panel se perciba tambien con contenido alto.


Cambios v1.10:
- Botones Canvas accesibles por teclado, con foco visible y estado deshabilitado.
- Acciones Guardar PNG, Imprimir, navegacion y Ver grande deshabilitadas hasta generar una vista previa.
- Barra de scroll principal, tabla y detalles sustituidas por scrollbar Canvas mas moderno.
- Ficha rapida de partida tras seleccionar TXT: lote, piezas validas, articulo, recepcion y rango real de peso.
- Validacion por bloques: partida, fechas, rango/boxes e impresora.
- Cache de validacion de partida para no releer el TXT innecesariamente al cambiar parametros.
- Calendario con festivos marcados y aviso si la fecha elegida genera una salida no laborable.
- Vista de etiqueta grande desde la previsualizacion.
- Guardado de preferencias tambien al editar y al cerrar la aplicacion.
- Tipografias generales ampliadas para mejorar lectura.


Cambios v1.11:
- Corregido el dibujo de los recuadros Canvas para que el borde superior/inferior no quede tapado por el contenido interno.
- Añadido borde propio a la banda de cabecera y al cuerpo de cada bloque.
- Añadido borde visible al header superior de la aplicacion y al body principal.


Cambios v1.12:
- Reforzado el borde de los bloques Canvas con borde real de widget y lineas explicitas superior, inferior y laterales.
- Reubicados los logos del header: Finura a la izquierda y Rodriguez a la derecha.


Cambios v1.13:
- Normalizados todos los bordes de bloques Canvas para evitar dobles lineas, cortes y grosores distintos.
- Eliminada la mezcla de borde real de widget, lineas manuales y borde interno solapado en los paneles.
- Ajustados los bordes de la barra de flujo y las tarjetas de resumen para que no queden pegados al limite del Canvas.


Cambios v1.14:
- Eliminado el borde de la banda de titulo de los recuadros, manteniendo solo texto y acento rojo.
- Reubicados los logos del header: Rodriguez a la izquierda y Finura a la derecha.


Cambios v1.15:
- Eliminadas las rayitas rojas/acento de los titulos de los recuadros para dejar los encabezados mas limpios.


Cambios v1.16:
- Actualizado el icono de la aplicacion desde la nueva imagen de etiqueta.
- Generado ICONO_SUITE_RRHH.ico multirresolucion con tamanos 16, 24, 32, 48, 64, 128 y 256 px.
- Generados PNGs auxiliares por tamano para el icono de ventana en entornos donde no se use iconbitmap.


Cambios v1.17:
- Eliminado el fondo/recuadro blanco exterior del icono manteniendo intacta la etiqueta blanca central.
- Regenerado el ICO multirresolucion y los PNGs auxiliares con esquinas transparentes.


Cambios v1.18:
- Añadido crear_instalador_completo.bat para generar el ejecutable con PyInstaller y el instalador final con Inno Setup.
- Añadido instalador_etiquetado_box.iss con icono, accesos directos y creacion de carpetas C:\Codex\App_etiquetado_box.
- Añadido instalar_en_equipo_destino.bat para crear un paquete USB instalable sin Inno Setup en el equipo destino.
- El instalador/paquete resultante puede llevarse en un USB al equipo destino sin instalar Python, PyInstaller ni Inno Setup alli.


Cambios v1.19:
- Eliminada la creacion de C:\Codex en el equipo destino.
- La aplicacion instalada guarda preferencias y exportaciones dentro de la carpeta de instalacion en Program Files.
- El instalador copia una configuracion editable a la carpeta de instalacion y concede permisos de modificacion a usuarios.


Cambios v1.20:
- Separado el diseño de etiqueta a config/plantilla_etiqueta.json manteniendo el aspecto actual por defecto.
- Añadido editor grafico oculto para informatica con acceso Ctrl+Alt+D.
- El editor permite seleccionar, arrastrar, ocultar, cambiar tamaño/posicion/fuente y guardar/restaurar elementos de la etiqueta.
- La contraseña por defecto del editor es admin y puede cambiarse creando config/editor_password.txt con la nueva clave.


Cambios v1.21:
- Mejorado el editor oculto con rejilla, guias de alineacion, resaltado al pasar el raton y selector de zoom.
- Añadido movimiento fino con teclado: flechas mueven 1 px y Shift+flechas mueve 10 px.
- Añadidos deshacer/rehacer, duplicar elementos, ordenar capas, bloquear/desbloquear y guardar/cargar plantillas JSON.
- Añadida validacion antes de guardar para detectar campos importantes ocultos, elementos fuera de etiqueta, tamanos invalidos o IDs duplicados.


Cambios v1.29:
- Editor en modo sencillo por defecto: el panel lateral muestra solo lo habitual y oculta los parametros tecnicos hasta activarlos.
- Añadido panel contextual del elemento seleccionado con leyenda, texto, variable, tamaño, alineacion, visibilidad, bloqueo y aplicacion directa.
- Añadida insercion guiada de datos frecuentes de etiqueta, con nombres claros y sin escribir variables tecnicas.
- Añadido estado de plantilla en vivo, margen seguro visible en la vista previa y reparacion automatica de problemas basicos.
- La lista de elementos y las variables usadas muestran nombres legibles; el doble clic permite editar textos y leyendas con menos pasos.


Cambios v1.30:
- El editor muestra estados claros de cambios guardados, cambios sin guardar y cambios escritos sin aplicar.
- Los campos del panel aplican cambios al perder foco o pulsar Enter, manteniendo el boton Aplicar cambios para confirmacion manual.
- La seleccion y redimensionado de campos con leyenda usan la altura real del elemento, tambien en campos largos como articulo.
- El margen seguro del editor usa el mismo margen de impresion que la salida Windows.
- Añadido selector de tamaños comunes para etiquetas Citizen, con reescalado proporcional de la plantilla.
- Las variables y alineaciones del panel se muestran con nombres legibles en castellano.
- La accion Guardar como pasa a Exportar copia para diferenciarla del guardado activo de impresion.
- La tecla Supr elimina con confirmacion en lugar de ocultar el elemento sin nombrarlo.


Cambios v1.31:
- Añadida ayuda interna del editor de etiquetas, accesible desde el boton Ayuda o con F1.
- Modo sencillo mas limpio: se dejan visibles las acciones habituales y se ocultan herramientas tecnicas hasta activar parametros tecnicos.
- Los desplegables, checks y tamaño de letra del panel aplican cambios de forma consistente.
- Cargar plantillas, cargar backups y deshacer/rehacer sincronizan el selector de tamaño Citizen.
- Validaciones, eliminacion y avisos muestran nombres legibles de campos en lugar de identificadores tecnicos.
- Reparar plantilla muestra que ajustes ha aplicado y tambien corrige altura de campos con leyenda.
- Actualizado el aviso de impresora para no asumir un unico tamaño fijo de etiqueta.


Cambios v1.32:
- Cabecera del editor simplificada con acciones principales visibles: Guardar, Probar, Validar y Ayuda.
- Cinta superior aligerada como zona de opciones avanzadas, reduciendo bordes y duplicidad visual.
- Panel izquierdo guiado por pasos: seleccionar bloque, añadir solo si falta algo y editar el bloque seleccionado.
- Lista de elementos mas compacta y limpia para dejar mas espacio a la edicion contextual.
- Estado inferior mas claro, separando guardado/cambios del mensaje operativo.
- Herramientas avanzadas y elementos libres quedan menos protagonistas para reducir errores de uso.


Cambios v1.33:
- Cinta superior normalizada en tres bandas limpias: plantilla/edicion, insercion de contenido y ajuste fino.
- Eliminadas las pestañas primitivas del editor para dejar grupos de acciones visibles, consistentes y mas faciles de recorrer.
- Reforzada la ayuda interna con una referencia completa de botones, campos, checks, listas y funciones del lienzo.
- Actualizadas las instrucciones de uso para reflejar el flujo real del editor: seleccionar, editar, probar y guardar.
- Ajustada la documentacion del selector de tamaños Citizen y de las acciones que afectan a la impresion real.


Cambios v1.34:
- Recuperada la estructura por pestañas de la v1.32: Archivo, Inicio, Insertar, Diseño y Vista.
- Aplicado a esas pestañas el acabado visual mas limpio de la v1.33, con grupos en tarjetas suaves y colores normalizados.
- El editor se abre maximizado por defecto para evitar cortes en la cinta superior.
- Añadido boton Pantalla y atajo F11 para alternar pantalla completa real; Esc sale de pantalla completa.
- Actualizada la ayuda interna para explicar la nueva estructura de pestañas y el modo de pantalla.


Cambios v1.35:
- Los elementos bloqueados desactivan sus campos de edicion, dejando activo solo el control Bloqueado para desbloquearlos.
- Validacion ampliada con avisos visuales: posibles solapes, texto cortado, bajo contraste y campos importantes fuera del margen seguro.
- El cambio de tamaño Citizen crea una copia de seguridad antes de reescalar y recuerda revisar el tamaño del driver de impresora.
- La vista de etiqueta incorpora scroll horizontal/vertical y desplazamiento con boton central o Shift + arrastrar para trabajar con zoom alto.
- Los mensajes de eliminar, restaurar, ocultar, mover y editar usan nombres humanos del bloque en lugar de identificadores tecnicos.
- El boton Pantalla cambia a Salir pantalla cuando esta activo para que el retorno sea mas evidente.


Cambios v1.36:
- La plantilla se normaliza por defecto para que todos los bloques visibles entren dentro del margen seguro en cualquier tamaño de etiqueta seleccionado.
- El renderizado, el guardado, la carga de plantillas y el cambio de tamaño Citizen aplican el margen seguro de forma automatica y predecible.
- El arranque de la aplicacion y la apertura del editor se muestran una sola vez, ya maximizados, evitando ventanas intermedias y parpadeos.
- Corregido Salir pantalla: el boton, F11 y Esc leen el estado real de pantalla completa y vuelven al editor maximizado normal.
- La plantilla incluida en config/plantilla_etiqueta.json queda verificada sin elementos visibles fuera del margen seguro.


Cambios v1.37:
- Rediseñada la cinta superior del editor con pestañas propias mas limpias y estado activo mas evidente.
- Sustituidos los grupos con aspecto de formulario por una banda continua con separadores discretos y mejor espaciado.
- Pulida la cabecera del editor para que las acciones principales queden mas sobrias y alineadas.
- Mantenidas las funciones existentes de la cinta, incluyendo pantalla completa, ayuda, validacion, prueba y gestion de plantilla.


Cambios v1.38:
- Añadido tamaño personalizado en el editor: ancho y alto en mm entre 25 y 220.
- El cambio de tamaño reescala desde el margen seguro actual al nuevo margen seguro para aprovechar mejor el area util.
- Aumentado el margen seguro de impresion de 3 mm a 4 mm.
- Ajustada la plantilla por defecto para nacer dentro del margen seguro nuevo, con columnas calculadas y sin avisos de validacion iniciales.
- Mejorada la validacion de campos con leyenda para evaluar leyenda y valor como bloques separados.
- Reparar plantilla usa ahora el margen seguro real en mm, no un margen fijo en pixeles.


Cambios v1.39:
- El margen seguro pasa a ser editable desde la pestaña Diseño del editor, con rango controlado de 1 a 12 mm.
- La vista previa puede mostrar al instante el margen seguro real de la plantilla para revisar si el contenido queda dentro.
- Las acciones de alinear, centrar, ocupar ancho completo, reparar y cambiar tamaño usan el margen seguro configurado en la plantilla.
- La cinta Inicio incorpora controles de texto estilo Word: tamaño directo, A-/A+, negrita y alineacion izquierda/centro/derecha.
- Los campos con leyenda aplican tambien la alineacion al valor impreso, no solo a textos simples.
- La ayuda del editor documenta las nuevas funciones de margen seguro, tamaño de letra y alineacion.


Cambios v1.40:
- Añadido config/config_salazon.csv para definir por articulo los rangos de peso y dias en sal por defecto.
- El rango de peso ya no se escribe a mano: al cargar la partida se ofrece un desplegable con los rangos configurados para el articulo detectado.
- Al seleccionar un rango se precargan los dias en sal indicados en el CSV, manteniendolos editables para ajustes puntuales.
- La etiqueta ya no muestra un bloque independiente de rango de peso: el rango queda integrado en el nombre del articulo.
- La plantilla por defecto aprovecha el espacio liberado para ampliar la fecha de salida y el articulo.
- El editor queda mas limpio: se retiran opciones de rango de peso de los campos recomendados y la ayuda explica el nuevo criterio.


Cambios v1.28:
- Rediseñado el editor con una cinta superior tipo Office organizada por pestañas: Archivo, Inicio, Insertar, Diseño y Vista.
- Repartida la funcionalidad del editor: la cinta contiene acciones frecuentes y el lateral queda centrado en elementos, variables, pie y propiedades finas.
- Añadida validacion manual de plantilla desde la cinta, sin necesidad de guardar.
- Agrupadas acciones de edicion, insercion, alineacion, capas, vista e impresion de prueba para reducir busqueda y duplicidad visual.


Cambios v1.27:
- Los dias en sal se inicializan siempre a 0 y ya no se recuperan de la ultima sesion.
- El editor muestra tipos de elemento con nombres claros en castellano en lugar de valores internos.
- Añadidas acciones rapidas para centrar horizontal/vertical y proteger la estructura de la etiqueta.
- El editor muestra un resumen de variables usadas en la plantilla para detectar rapidamente campos activos.
- Reordenado el bloque de añadir elementos para que el selector y los botones no se apelotonen.


Cambios v1.26:
- El editor avisa al cerrar si hay cambios sin guardar y permite guardarlos en ese momento.
- Añadido boton "Ult. backup" para cargar la ultima copia de seguridad de plantilla y revisarla antes de guardarla.
- Añadido boton "Imprimir prueba" para enviar una unica etiqueta con el diseno actual del editor.
- La vista previa del editor usa el box real seleccionado si ya hay una vista previa generada en la aplicacion principal.


Cambios v1.25:
- Mejorado el foco del editor grafico para que al abrirlo y trabajar sobre el no capture la rueda la ventana principal.
- La rueda del raton en el panel izquierdo del editor desplaza propiedades/lista de elementos sin mover la aplicacion de fondo.
- Añadida ayuda visible y resumen del elemento seleccionado para saber rapidamente que se esta editando.
- Refactorizado el calculo de impresion centrada con margen de seguridad de 3 mm para comprobarlo sin depender de una impresion fisica.


Cambios v1.24:
- Eliminado el campo temperatura de la interfaz, preferencias, validaciones, generacion y editor de plantillas.
- La etiqueta ya no muestra numero de articulo ni temperatura; el articulo se imprime solo con el nombre.
- Actualizada la etiqueta por defecto: rotulo "FECHA DE SALIDA SAL:", "FECHA DE ENTRADA EN SAL", lote mas grande y articulo al final con multilinea.
- Ajustada la impresion Windows para mantener proporcion y centrar el contenido sobre el tamano fisico de la etiqueta, dejando margen de seguridad para esquinas redondeadas.


Cambios v1.23:
- Mejorado el editor oculto para que el ajuste de etiquetas sea mas claro: copiar/pegar, alinear a izquierda/centro y ocupar ancho completo.
- Añadidos botones de variables rapidas y presets de pie para construir textos como BOX, lote o dias en sal sin escribir las claves a mano.
- Añadido tirador visual para redimensionar elementos desde la esquina inferior derecha de la seleccion.
- Añadido soporte de texto multilinea e interlineado para campos largos como el articulo.
- La plantilla guarda copia de seguridad automatica antes de sobrescribirse y bloquea elementos estructurales de la etiqueta por defecto.


Cambios v1.22:
- El editor permite añadir elementos nuevos: texto fijo, campo variable, campo con leyenda, linea y rectangulo.
- Se puede editar ID, tipo, variable asociada, plantilla combinada, colores, grosor, offset de valor, alineacion, bloqueo y visibilidad.
- Añadido selector de variables disponibles y vista de ejemplo para variables/plantillas combinadas.
- Añadidos eliminar elemento y restaurar solo el elemento seleccionado desde la plantilla por defecto.
- El panel de propiedades del editor incorpora scroll interno para pantallas medianas.
