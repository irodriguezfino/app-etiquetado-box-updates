﻿from __future__ import annotations

import json
import math
import re
import shutil
import sys
import csv
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont


APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", APP_DIR))
CONFIG_DIR = APP_DIR / "config" if (APP_DIR / "config").exists() else RESOURCE_DIR / "config"
ARTICULOS_PATH = CONFIG_DIR / "articulos.txt"
SALAZON_CONFIG_PATH = CONFIG_DIR / "config_salazon.csv"
FESTIVOS_PATH = CONFIG_DIR / "festivos.json"
LABEL_TEMPLATE_PATH = CONFIG_DIR / "plantilla_etiqueta.json"

LABEL_WIDTH_MM = 111
LABEL_HEIGHT_MM = 162
DEFAULT_DPI = 300
PRINT_SAFE_MARGIN_MM = 4.0
SAFE_MARGIN_MIN_MM = 1.0
SAFE_MARGIN_MAX_MM = 12.0
BASE_LABEL_WIDTH = int(LABEL_WIDTH_MM / 25.4 * DEFAULT_DPI)
BASE_LABEL_HEIGHT = int(LABEL_HEIGHT_MM / 25.4 * DEFAULT_DPI)
DEFAULT_SAFE_MARGIN_X = int(BASE_LABEL_WIDTH * PRINT_SAFE_MARGIN_MM / LABEL_WIDTH_MM)
DEFAULT_SAFE_MARGIN_Y = int(BASE_LABEL_HEIGHT * PRINT_SAFE_MARGIN_MM / LABEL_HEIGHT_MM)
DEFAULT_SAFE_WIDTH = BASE_LABEL_WIDTH - DEFAULT_SAFE_MARGIN_X * 2
DEFAULT_SAFE_HEIGHT = BASE_LABEL_HEIGHT - DEFAULT_SAFE_MARGIN_Y * 2
DEFAULT_COLUMN_GAP = 28
DEFAULT_COLUMN_WIDTH = (DEFAULT_SAFE_WIDTH - DEFAULT_COLUMN_GAP) // 2
DEFAULT_COLUMN_X2 = DEFAULT_SAFE_MARGIN_X + DEFAULT_COLUMN_WIDTH + DEFAULT_COLUMN_GAP

CITIZEN_LABEL_SIZE_PRESETS = (
    ("111 x 162 mm - actual salazon", 111.0, 162.0),
    ("100 x 150 mm - envio grande", 100.0, 150.0),
    ("102 x 152 mm - 4 x 6 pulgadas", 102.0, 152.0),
    ("105 x 148 mm - A6", 105.0, 148.0),
    ("100 x 100 mm - cuadrada", 100.0, 100.0),
    ("80 x 50 mm - producto", 80.0, 50.0),
    ("70 x 50 mm - producto", 70.0, 50.0),
    ("60 x 40 mm - producto pequeno", 60.0, 40.0),
    ("50 x 30 mm - trazabilidad", 50.0, 30.0),
    ("40 x 30 mm - pequena", 40.0, 30.0),
)

WEEKDAY_ES = {
    0: "LUNES",
    1: "MARTES",
    2: "MIERCOLES",
    3: "JUEVES",
    4: "VIERNES",
    5: "SABADO",
    6: "DOMINGO",
}


@dataclass(frozen=True)
class Pieza:
    lote: str
    fecha_recepcion: date
    articulo_codigo: str
    articulo_clave: str
    articulo_nombre: str
    peso: float
    linea: int
    raw: str


@dataclass(frozen=True)
class RangoSalazon:
    articulo_codigo: str
    articulo_nombre: str
    rango_min: float
    rango_max: float
    dias_sal: int
    rango_texto: str = ""

    @property
    def range_label(self) -> str:
        if self.rango_texto:
            return self.rango_texto
        return f"{format_decimal(self.rango_min)} - {format_decimal(self.rango_max)} kg"

    @property
    def display_label(self) -> str:
        return f"{self.range_label} | {self.dias_sal} dias | {self.articulo_nombre}"


@dataclass(frozen=True)
class BoxEtiqueta:
    box_numero: int
    lote: str
    articulo_codigo: str
    articulo_nombre: str
    fecha_recepcion: date
    fecha_entrada: date
    fecha_salida: date
    dia_salida: str
    dias_sal: int
    unidades: int
    total_piezas_rango: int
    rango_min: float
    rango_max: float
    rango_real_min: float
    rango_real_max: float
    etiquetas: int
    pesos: tuple[float, ...]


@dataclass(frozen=True)
class Festivo:
    fecha: date
    nombre: str


@dataclass(frozen=True)
class ResultadoGeneracion:
    lote: str
    total_lineas: int
    total_validas: int
    total_filtradas: int
    articulo_nombre: str
    fecha_recepcion: date
    fecha_salida: date
    boxes: tuple[BoxEtiqueta, ...]
    avisos: tuple[str, ...]

    @property
    def total_etiquetas(self) -> int:
        return sum(box.etiquetas for box in self.boxes)


def parse_decimal(text: str) -> float:
    clean = str(text).strip().replace(",", ".")
    if not clean:
        raise ValueError("valor vacio")
    return float(clean)


def format_decimal(value: float) -> str:
    text = f"{value:.2f}".replace(".", ",")
    return text.rstrip("0").rstrip(",")


def calculate_centered_print_rect(
    physical_width: int,
    physical_height: int,
    printable_width: int,
    printable_height: int,
    offset_x: int,
    offset_y: int,
    dpi_x: int,
    dpi_y: int,
    image_width: int,
    image_height: int,
    safe_margin_mm: float = PRINT_SAFE_MARGIN_MM,
) -> tuple[int, int, int, int]:
    physical_width = max(int(physical_width or printable_width), 1)
    physical_height = max(int(physical_height or printable_height), 1)
    printable_width = max(int(printable_width or physical_width), 1)
    printable_height = max(int(printable_height or physical_height), 1)
    dpi_x = max(int(dpi_x or DEFAULT_DPI), 1)
    dpi_y = max(int(dpi_y or DEFAULT_DPI), 1)
    safe_x = min(int(safe_margin_mm / 25.4 * dpi_x), max((physical_width - 1) // 2, 0))
    safe_y = min(int(safe_margin_mm / 25.4 * dpi_y), max((physical_height - 1) // 2, 0))
    image_ratio = max(image_width, 1) / max(image_height, 1)
    target_area_w = max(1, physical_width - (safe_x * 2))
    target_area_h = max(1, physical_height - (safe_y * 2))
    if target_area_w / target_area_h > image_ratio:
        target_h = target_area_h
        target_w = int(target_h * image_ratio)
    else:
        target_w = target_area_w
        target_h = int(target_w / image_ratio)
    left_physical = safe_x + (target_area_w - target_w) // 2
    top_physical = safe_y + (target_area_h - target_h) // 2
    left = left_physical - int(offset_x or 0)
    top = top_physical - int(offset_y or 0)
    return left, top, left + target_w, top + target_h


def parse_date(text: str) -> date:
    value = str(text).strip()
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            pass
    raise ValueError("Introduce la fecha en formato dd/mm/aaaa.")


def normalize_lote_from_filename(filename: str) -> str:
    digits = "".join(re.findall(r"\d", Path(filename).stem))
    return digits[:6] if len(digits) >= 6 else (digits or Path(filename).stem[:6])


def normalize_article_code(value: str) -> str:
    return re.sub(r"\D", "", str(value or ""))


def article_code_variants(value: str) -> set[str]:
    clean = normalize_article_code(value)
    variants: set[str] = set()
    if not clean:
        return variants
    variants.add(clean)
    stripped = clean.lstrip("0") or "0"
    variants.add(stripped)
    if len(stripped) > 2:
        variants.add(stripped[:-2].lstrip("0") or "0")
    if len(clean) > 2:
        variants.add(clean[:-2].lstrip("0") or "0")
    return {item for item in variants if item}


def article_codes_match(left: str, right: str) -> bool:
    return bool(article_code_variants(left) & article_code_variants(right))


def _article_name_without_range(name: str) -> str:
    text = str(name or "").strip()
    text = re.sub(r"\s+\d+(?:[,.]\d+)?\s*[-–]\s*\d+(?:[,.]\d+)?\s*$", "", text).strip()
    text = re.sub(r"\s+[<+>]\s*\d+(?:[,.]\d+)?\s*$", "", text).strip()
    return text


def _extract_weight_range(name: str) -> tuple[float, float, str]:
    text = str(name or "").strip()
    matches = list(re.finditer(r"(\d+(?:[,.]\d+)?)\s*[-–]\s*(\d+(?:[,.]\d+)?)", text))
    if matches:
        match = matches[-1]
        min_weight = parse_decimal(match.group(1))
        max_weight = parse_decimal(match.group(2))
        if min_weight > max_weight:
            min_weight, max_weight = max_weight, min_weight
        return min_weight, max_weight, f"{format_decimal(min_weight)} - {format_decimal(max_weight)} kg"
    less_match = re.search(r"(?:^|\s)<\s*(\d+(?:[,.]\d+)?)\s*$", text)
    if less_match:
        max_weight = parse_decimal(less_match.group(1))
        return 0.0, max_weight, f"< {format_decimal(max_weight)} kg"
    greater_match = re.search(r"(?:^|\s)(?:\+|>)\s*(\d+(?:[,.]\d+)?)\s*$", text)
    if greater_match:
        min_weight = parse_decimal(greater_match.group(1))
        return min_weight, 999.0, f"> {format_decimal(min_weight)} kg"
    if not matches:
        raise ValueError(f"No se encontro rango de peso en el nombre de articulo: {name}")


def load_salazon_ranges(path: Path = SALAZON_CONFIG_PATH) -> tuple[RangoSalazon, ...]:
    if not path.exists():
        return ()
    ranges: list[RangoSalazon] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(2048)
        handle.seek(0)
        has_header = bool(re.search(r"codigo|articulo|dias|sal", sample.splitlines()[0] if sample else "", re.IGNORECASE))
        reader = csv.DictReader(handle, delimiter=";") if has_header else csv.reader(handle, delimiter=";")
        for row_no, row in enumerate(reader, start=2 if has_header else 1):
            try:
                if has_header:
                    clean_row = {str(key or "").strip().lower(): str(value or "").strip() for key, value in row.items()}
                    code = clean_row.get("codigo") or clean_row.get("numero") or clean_row.get("articulo") or clean_row.get("numero_articulo") or clean_row.get("codigo_articulo") or ""
                    name = clean_row.get("nombre") or clean_row.get("nombre_articulo") or clean_row.get("descripcion") or ""
                    days_text = clean_row.get("dias") or clean_row.get("dias_sal") or clean_row.get("dias_en_sal") or ""
                else:
                    if len(row) < 3:
                        continue
                    code, name, days_text = (str(item).strip() for item in row[:3])
                if not code or not name:
                    continue
                min_weight, max_weight, range_label = _extract_weight_range(name)
                ranges.append(
                    RangoSalazon(
                        articulo_codigo=normalize_article_code(code),
                        articulo_nombre=name.strip(),
                        rango_min=min_weight,
                        rango_max=max_weight,
                        dias_sal=int(float(str(days_text).strip().replace(",", "."))),
                        rango_texto=range_label,
                    )
                )
            except Exception as exc:
                raise ValueError(f"Linea {row_no} no valida en config_salazon.csv: {exc}") from exc
    return tuple(ranges)


def salazon_ranges_for_article(article_code: str, ranges: Iterable[RangoSalazon] | None = None) -> tuple[RangoSalazon, ...]:
    ranges = tuple(ranges) if ranges is not None else load_salazon_ranges()
    matches = [item for item in ranges if article_codes_match(article_code, item.articulo_codigo)]
    return tuple(sorted(matches, key=lambda item: (item.rango_min, item.rango_max, item.dias_sal, item.articulo_nombre)))


def load_article_legend(path: Path = ARTICULOS_PATH) -> dict[str, str]:
    result: dict[str, str] = {}
    if path.exists():
        pattern = re.compile(r"^\s*(\d+)\s*[-;]\s*(.+?)\s*$")
        for line_no, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), start=1):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            match = pattern.match(line)
            if not match:
                raise ValueError(f"Linea {line_no} no valida en leyenda de articulos: {line}")
            code, name = match.groups()
            result[code.strip()] = name.strip()
    for item in load_salazon_ranges():
        base_name = _article_name_without_range(item.articulo_nombre) or item.articulo_nombre
        result.setdefault(item.articulo_codigo, base_name)
    if not result:
        raise ValueError("La leyenda/configuracion de articulos esta vacia.")
    return result


def resolve_article(article_code: str, legend: dict[str, str]) -> tuple[str, str]:
    clean = normalize_article_code(article_code)
    candidates = [clean[:length] for length in range(min(len(clean), 6), 0, -1)]
    stripped = clean.lstrip("0")
    if stripped:
        candidates.append(stripped)
    if len(stripped) > 2:
        candidates.append(stripped[:-2])
    if len(clean) > 2:
        candidates.append(clean[:-2].lstrip("0"))
    for key in candidates:
        if key in legend:
            return key, legend[key]
    for key, name in legend.items():
        if article_codes_match(clean, key):
            return key, name
    return clean[:3] if clean else "", f"ARTICULO {article_code}"


def parse_partida_file(path: Path, legend: dict[str, str]) -> list[Pieza]:
    if not path.exists():
        raise FileNotFoundError(f"No existe el fichero de partida: {path}")
    lote = normalize_lote_from_filename(path.name)
    piezas: list[Pieza] = []
    errors: list[str] = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), start=1):
        if not raw.strip():
            continue
        parts = [part.strip() for part in raw.split(";")]
        if len(parts) < 5:
            errors.append(f"Linea {line_no}: columnas insuficientes")
            continue
        try:
            fecha_recepcion = parse_date(parts[1])
        except Exception:
            errors.append(f"Linea {line_no}: fecha de recepcion no valida ({parts[1]!r})")
            continue
        article_code = parts[3]
        weight_text = next((part for part in reversed(parts) if part.strip()), "")
        try:
            weight = parse_decimal(weight_text)
        except Exception:
            errors.append(f"Linea {line_no}: peso no valido ({weight_text!r})")
            continue
        article_key, article_name = resolve_article(article_code, legend)
        piezas.append(Pieza(lote, fecha_recepcion, article_code, article_key, article_name, weight, line_no, raw))
    if not piezas:
        detail = "\n".join(errors[:10])
        raise ValueError(f"No se pudo leer ninguna pieza valida.\n{detail}")
    return piezas


def easter_sunday(year: int) -> date:
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(year, month, day)


def computed_holidays(year: int) -> dict[date, str]:
    easter = easter_sunday(year)
    holidays = {
        date(year, 1, 1): "Ano Nuevo",
        date(year, 1, 6): "Epifania del Senor",
        easter - timedelta(days=3): "Jueves Santo",
        easter - timedelta(days=2): "Viernes Santo",
        date(year, 4, 23): "Dia de Castilla y Leon",
        date(year, 5, 1): "Fiesta del Trabajo",
        date(year, 8, 15): "Asuncion de la Virgen",
        date(year, 10, 12): "Fiesta Nacional de Espana",
        date(year, 12, 8): "Inmaculada Concepcion",
        date(year, 12, 25): "Navidad",
        easter - timedelta(days=47): "Martes de Carnaval (La Baneza)",
        date(year, 8, 16): "San Roque (La Baneza)",
    }
    # Traslados habituales cuando Todos los Santos y Constitucion caen en domingo.
    if date(year, 11, 1).weekday() == 6:
        holidays[date(year, 11, 2)] = "Traslado Todos los Santos"
    else:
        holidays[date(year, 11, 1)] = "Todos los Santos"
    if date(year, 12, 6).weekday() == 6:
        holidays[date(year, 12, 7)] = "Traslado Dia de la Constitucion"
    else:
        holidays[date(year, 12, 6)] = "Dia de la Constitucion"
    return holidays


def load_manual_holidays(path: Path = FESTIVOS_PATH) -> tuple[dict[date, str], set[date]]:
    if not path.exists():
        return {}, set()
    data = json.loads(path.read_text(encoding="utf-8"))
    extras: dict[date, str] = {}
    for item in data.get("festivos_adicionales", []):
        day = date.fromisoformat(str(item["fecha"]))
        extras[day] = str(item.get("nombre") or "Festivo adicional")
    workdays: set[date] = set()
    for item in data.get("fechas_laborables_excepcionales", []):
        if isinstance(item, dict):
            workdays.add(date.fromisoformat(str(item["fecha"])))
        else:
            workdays.add(date.fromisoformat(str(item)))
    return extras, workdays


def holidays_for_year(year: int, path: Path = FESTIVOS_PATH) -> dict[date, str]:
    holidays = computed_holidays(year)
    extras, workdays = load_manual_holidays(path)
    holidays.update({day: name for day, name in extras.items() if day.year == year})
    for day in workdays:
        holidays.pop(day, None)
    return holidays


def validate_workday(day: date) -> tuple[bool, str]:
    if day.weekday() >= 5:
        return False, WEEKDAY_ES[day.weekday()]
    holidays = holidays_for_year(day.year)
    if day in holidays:
        return False, holidays[day]
    return True, ""


def calculate_exit_date(entry_date: date, days_in_salt: int) -> date:
    if days_in_salt < 0:
        raise ValueError("Los dias en sal no pueden ser negativos.")
    return entry_date + timedelta(days=days_in_salt)


def build_boxes(
    partida_path: Path,
    entry_date: date,
    days_in_salt: int,
    min_weight: float,
    max_weight: float,
    units_per_box: int,
    labels_per_box: int,
    legend: dict[str, str] | None = None,
    article_name_override: str | None = None,
) -> ResultadoGeneracion:
    if min_weight > max_weight:
        raise ValueError("El peso minimo no puede ser mayor que el peso maximo.")
    if units_per_box <= 0:
        raise ValueError("Las unidades por box deben ser mayores que cero.")
    if labels_per_box <= 0:
        raise ValueError("Las etiquetas por box deben ser mayores que cero.")

    legend = legend or load_article_legend()
    piezas = parse_partida_file(partida_path, legend)
    filtered = [pieza for pieza in piezas if min_weight <= pieza.peso <= max_weight]
    if not filtered:
        raise ValueError("No hay jamones dentro del rango de peso indicado.")

    article_labels = sorted({pieza.articulo_nombre for pieza in filtered})
    article_name = str(article_name_override or "").strip() or (article_labels[0] if len(article_labels) == 1 else " / ".join(article_labels))
    reception_dates = sorted({pieza.fecha_recepcion for pieza in filtered})
    fecha_recepcion = reception_dates[0]
    exit_date = calculate_exit_date(entry_date, days_in_salt)
    ok, reason = validate_workday(exit_date)
    if not ok:
        raise ValueError(f"La fecha de salida {exit_date:%d/%m/%Y} no es laborable: {reason}.")

    boxes: list[BoxEtiqueta] = []
    total_boxes = math.ceil(len(filtered) / units_per_box)
    for index in range(total_boxes):
        chunk = filtered[index * units_per_box : (index + 1) * units_per_box]
        pesos = tuple(pieza.peso for pieza in chunk)
        boxes.append(
            BoxEtiqueta(
                box_numero=index + 1,
                lote=chunk[0].lote,
                articulo_codigo=chunk[0].articulo_clave,
                articulo_nombre=article_name,
                fecha_recepcion=fecha_recepcion,
                fecha_entrada=entry_date,
                fecha_salida=exit_date,
                dia_salida=WEEKDAY_ES[exit_date.weekday()],
                dias_sal=days_in_salt,
                unidades=len(chunk),
                total_piezas_rango=len(filtered),
                rango_min=min_weight,
                rango_max=max_weight,
                rango_real_min=min(pesos),
                rango_real_max=max(pesos),
                etiquetas=labels_per_box,
                pesos=pesos,
            )
        )

    avisos: list[str] = []
    if len(filtered) % units_per_box:
        avisos.append(f"El ultimo box queda como resto con {len(filtered) % units_per_box} unidades.")
    if len(article_labels) > 1:
        avisos.append("El rango contiene mas de un articulo; revisa la partida antes de imprimir.")
    if len(reception_dates) > 1:
        avisos.append("El rango contiene varias fechas de recepcion; se muestra la primera.")

    return ResultadoGeneracion(
        lote=normalize_lote_from_filename(partida_path.name),
        total_lineas=sum(1 for line in partida_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()),
        total_validas=len(piezas),
        total_filtradas=len(filtered),
        articulo_nombre=article_name,
        fecha_recepcion=fecha_recepcion,
        fecha_salida=exit_date,
        boxes=tuple(boxes),
        avisos=tuple(avisos),
    )


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf"),
        Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def _center_text(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], text: str, font, fill="black") -> None:
    bbox = draw.textbbox((0, 0), text, font=font)
    width = bbox[2] - bbox[0]
    height = bbox[3] - bbox[1]
    x = box[0] + ((box[2] - box[0]) - width) // 2
    y = box[1] + ((box[3] - box[1]) - height) // 2
    draw.text((x, y), text, font=font, fill=fill)


DEFAULT_LABEL_TEMPLATE = {
    "version": 1,
    "label_width_mm": LABEL_WIDTH_MM,
    "label_height_mm": LABEL_HEIGHT_MM,
    "safe_margin_mm": PRINT_SAFE_MARGIN_MM,
    "base_width": BASE_LABEL_WIDTH,
    "base_height": BASE_LABEL_HEIGHT,
    "background": "white",
    "elements": [
        {"id": "outer_border", "type": "rect", "x": DEFAULT_SAFE_MARGIN_X, "y": DEFAULT_SAFE_MARGIN_Y, "w": DEFAULT_SAFE_WIDTH, "h": DEFAULT_SAFE_HEIGHT, "outline": "black", "line_width": 5, "visible": True, "locked": True},
        {"id": "header_bar", "type": "rect", "x": DEFAULT_SAFE_MARGIN_X, "y": DEFAULT_SAFE_MARGIN_Y, "w": DEFAULT_SAFE_WIDTH, "h": 122, "fill": "black", "outline": "black", "line_width": 1, "visible": True, "locked": True},
        {"id": "titulo", "type": "text", "text": "HOJA DE SALAZON", "x": DEFAULT_SAFE_MARGIN_X, "y": DEFAULT_SAFE_MARGIN_Y + 10, "w": DEFAULT_SAFE_WIDTH, "h": 98, "font_size": 62, "min_size": 48, "bold": True, "fill": "white", "background": "black", "align": "center", "visible": True},
        {"id": "salida_label", "type": "text", "text": "FECHA DE SALIDA SAL:", "x": DEFAULT_SAFE_MARGIN_X, "y": 180, "w": DEFAULT_COLUMN_WIDTH, "h": 54, "font_size": 42, "min_size": 32, "bold": True, "fill": "#222222", "align": "left", "visible": True},
        {"id": "dia_salida", "type": "value", "key": "dia_salida", "x": DEFAULT_SAFE_MARGIN_X, "y": 240, "w": DEFAULT_SAFE_WIDTH, "h": 112, "font_size": 112, "min_size": 78, "bold": True, "fill": "black", "align": "center", "visible": True},
        {"id": "fecha_salida", "type": "value", "key": "fecha_salida", "x": DEFAULT_SAFE_MARGIN_X, "y": 344, "w": DEFAULT_SAFE_WIDTH, "h": 112, "font_size": 106, "min_size": 76, "bold": True, "fill": "black", "align": "center", "visible": True},
        {"id": "linea_salida", "type": "line", "x1": DEFAULT_SAFE_MARGIN_X, "y1": 488, "x2": BASE_LABEL_WIDTH - DEFAULT_SAFE_MARGIN_X, "y2": 488, "fill": "black", "line_width": 5, "visible": True, "locked": True},
        {"id": "fecha_recepcion", "type": "field", "label": "FECHA RECEPCION", "key": "fecha_recepcion", "x": DEFAULT_SAFE_MARGIN_X, "y": 520, "w": DEFAULT_COLUMN_WIDTH, "label_size": 42, "value_size": 70, "min_size": 48, "bold": True, "label_fill": "#373737", "fill": "#0C0C0C", "visible": True},
        {"id": "fecha_entrada", "type": "field", "label": "FECHA DE ENTRADA EN SAL", "key": "fecha_entrada", "x": DEFAULT_COLUMN_X2, "y": 520, "w": DEFAULT_COLUMN_WIDTH, "label_size": 36, "value_size": 70, "min_size": 48, "bold": True, "label_fill": "#373737", "fill": "#0C0C0C", "visible": True},
        {"id": "linea_fechas", "type": "line", "x1": DEFAULT_SAFE_MARGIN_X, "y1": 690, "x2": BASE_LABEL_WIDTH - DEFAULT_SAFE_MARGIN_X, "y2": 690, "fill": "#878787", "line_width": 2, "visible": True},
        {"id": "lote", "type": "field", "label": "LOTE", "key": "lote", "x": DEFAULT_SAFE_MARGIN_X, "y": 720, "w": DEFAULT_SAFE_WIDTH, "label_size": 46, "value_size": 126, "min_size": 82, "bold": True, "label_fill": "#373737", "fill": "#0C0C0C", "visible": True},
        {"id": "linea_lote", "type": "line", "x1": DEFAULT_SAFE_MARGIN_X, "y1": 948, "x2": BASE_LABEL_WIDTH - DEFAULT_SAFE_MARGIN_X, "y2": 948, "fill": "#878787", "line_width": 2, "visible": True},
        {"id": "piezas_rango", "type": "field", "label": "PIEZAS RANGO", "key": "total_piezas_rango", "x": DEFAULT_SAFE_MARGIN_X, "y": 984, "w": DEFAULT_COLUMN_WIDTH, "label_size": 42, "value_size": 100, "min_size": 66, "bold": True, "label_fill": "#373737", "fill": "#0C0C0C", "visible": True},
        {"id": "unidades_box", "type": "field", "label": "UNID. BOX", "key": "unidades", "x": DEFAULT_COLUMN_X2, "y": 984, "w": DEFAULT_COLUMN_WIDTH, "label_size": 42, "value_size": 100, "min_size": 66, "bold": True, "label_fill": "#373737", "fill": "#0C0C0C", "visible": True},
        {"id": "linea_unidades", "type": "line", "x1": DEFAULT_SAFE_MARGIN_X, "y1": 1186, "x2": BASE_LABEL_WIDTH - DEFAULT_SAFE_MARGIN_X, "y2": 1186, "fill": "#878787", "line_width": 2, "visible": True},
        {"id": "articulo", "type": "field", "label": "ARTICULO", "key": "articulo_nombre", "x": DEFAULT_SAFE_MARGIN_X, "y": 1228, "w": DEFAULT_SAFE_WIDTH, "h": 472, "label_size": 48, "value_size": 102, "min_size": 52, "bold": True, "label_fill": "#373737", "fill": "#0C0C0C", "visible": True, "wrap": True, "line_spacing": 1.08},
        {"id": "linea_articulo", "type": "line", "x1": DEFAULT_SAFE_MARGIN_X, "y1": BASE_LABEL_HEIGHT - 154, "x2": BASE_LABEL_WIDTH - DEFAULT_SAFE_MARGIN_X, "y2": BASE_LABEL_HEIGHT - 154, "fill": "#878787", "line_width": 2, "visible": True},
        {"id": "linea_pie", "type": "line", "x1": DEFAULT_SAFE_MARGIN_X, "y1": BASE_LABEL_HEIGHT - 154, "x2": BASE_LABEL_WIDTH - DEFAULT_SAFE_MARGIN_X, "y2": BASE_LABEL_HEIGHT - 154, "fill": "black", "line_width": 3, "visible": True, "locked": True},
        {"id": "pie", "type": "value", "template": "BOX {box_numero} | {dias_sal} DIAS EN SAL", "x": DEFAULT_SAFE_MARGIN_X, "y": BASE_LABEL_HEIGHT - 126, "w": DEFAULT_SAFE_WIDTH, "h": 70, "font_size": 46, "min_size": 32, "bold": True, "fill": "black", "align": "left", "visible": True},
    ],
}


OBSOLETE_LABEL_ELEMENT_IDS = {"rango_peso", "linea_rango"}


def safe_margin_mm_from_template(template: dict | None = None) -> float:
    template = template or {}
    try:
        margin = float(template.get("safe_margin_mm", PRINT_SAFE_MARGIN_MM))
    except Exception:
        margin = PRINT_SAFE_MARGIN_MM
    return max(SAFE_MARGIN_MIN_MM, min(SAFE_MARGIN_MAX_MM, margin))


def _safe_margin_for_template(template: dict) -> tuple[int, int, int, int]:
    label_width_mm = float(template.get("label_width_mm", LABEL_WIDTH_MM) or LABEL_WIDTH_MM)
    label_height_mm = float(template.get("label_height_mm", LABEL_HEIGHT_MM) or LABEL_HEIGHT_MM)
    base_width = int(template.get("base_width", BASE_LABEL_WIDTH) or BASE_LABEL_WIDTH)
    base_height = int(template.get("base_height", BASE_LABEL_HEIGHT) or BASE_LABEL_HEIGHT)
    safe_margin_mm = safe_margin_mm_from_template(template)
    margin_x = int(base_width * safe_margin_mm / max(label_width_mm, 1))
    margin_y = int(base_height * safe_margin_mm / max(label_height_mm, 1))
    return margin_x, margin_y, base_width - margin_x, base_height - margin_y


def _clamp_element_to_box(element: dict, safe_box: tuple[int, int, int, int]) -> None:
    sx1, sy1, sx2, sy2 = safe_box
    kind = str(element.get("type", ""))
    if kind == "line":
        for key in ("x1", "x2"):
            element[key] = min(max(int(element.get(key, sx1)), sx1), sx2)
        for key in ("y1", "y2"):
            element[key] = min(max(int(element.get(key, sy1)), sy1), sy2)
        return
    if kind not in {"rect", "text", "value", "field"}:
        return
    x = int(element.get("x", sx1))
    y = int(element.get("y", sy1))
    width = int(element.get("w", max(1, sx2 - sx1)))
    height = int(element.get("h", 180 if kind == "field" else 70))
    max_width = max(1, sx2 - sx1)
    max_height = max(1, sy2 - sy1)
    width = min(max(width, 1), max_width)
    height = min(max(height, 1), max_height)
    x = min(max(x, sx1), sx2 - width)
    y = min(max(y, sy1), sy2 - height)
    element["x"] = x
    element["y"] = y
    element["w"] = width
    if "h" in element or kind in {"rect", "text", "value"}:
        element["h"] = height


def normalize_template_to_safe_area(template: dict) -> dict:
    normalized = json.loads(json.dumps(template))
    normalized["elements"] = [
        element for element in normalized.get("elements", [])
        if not (isinstance(element, dict) and str(element.get("id", "")) in OBSOLETE_LABEL_ELEMENT_IDS)
    ]
    safe_box = _safe_margin_for_template(normalized)
    for element in normalized.get("elements", []):
        if isinstance(element, dict) and element.get("visible", True):
            _clamp_element_to_box(element, safe_box)
    return normalized


DEFAULT_LABEL_TEMPLATE = normalize_template_to_safe_area(DEFAULT_LABEL_TEMPLATE)


def _editable_config_dir() -> Path:
    path = APP_DIR / "config"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _template_path() -> Path:
    editable = APP_DIR / "config" / "plantilla_etiqueta.json"
    if editable.exists():
        return editable
    bundled = RESOURCE_DIR / "config" / "plantilla_etiqueta.json"
    if bundled.exists():
        return bundled
    return editable


def load_label_template() -> dict:
    path = _template_path()
    if not path.exists():
        template = normalize_template_to_safe_area(DEFAULT_LABEL_TEMPLATE)
        save_label_template(template)
        return template
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or "elements" not in data:
            raise ValueError("Plantilla sin elementos.")
        data.setdefault("label_width_mm", LABEL_WIDTH_MM)
        data.setdefault("label_height_mm", LABEL_HEIGHT_MM)
        data.setdefault("base_width", int(float(data.get("label_width_mm", LABEL_WIDTH_MM)) / 25.4 * DEFAULT_DPI))
        data.setdefault("base_height", int(float(data.get("label_height_mm", LABEL_HEIGHT_MM)) / 25.4 * DEFAULT_DPI))
        data.setdefault("safe_margin_mm", PRINT_SAFE_MARGIN_MM)
        return normalize_template_to_safe_area(data)
    except Exception:
        return normalize_template_to_safe_area(DEFAULT_LABEL_TEMPLATE)


def label_size_from_template(template: dict | None = None) -> tuple[float, float]:
    template = template or {}
    try:
        width_mm = float(template.get("label_width_mm", LABEL_WIDTH_MM))
    except Exception:
        width_mm = LABEL_WIDTH_MM
    try:
        height_mm = float(template.get("label_height_mm", LABEL_HEIGHT_MM))
    except Exception:
        height_mm = LABEL_HEIGHT_MM
    return max(width_mm, 1.0), max(height_mm, 1.0)


def save_label_template(template: dict) -> Path:
    path = _editable_config_dir() / "plantilla_etiqueta.json"
    template = normalize_template_to_safe_area(template)
    if path.exists():
        backup_dir = path.parent / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        shutil.copy2(path, backup_dir / f"plantilla_etiqueta_backup_{stamp}.json")
    path.write_text(json.dumps(template, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def reset_label_template() -> Path:
    return save_label_template(normalize_template_to_safe_area(DEFAULT_LABEL_TEMPLATE))


def _label_values(box: BoxEtiqueta) -> dict[str, str]:
    footer = f"BOX {box.box_numero} | {box.dias_sal} DIAS EN SAL"
    rango_peso = f"{format_decimal(box.rango_min)} - {format_decimal(box.rango_max)} kg"
    rango_real = f"{format_decimal(box.rango_real_min)} - {format_decimal(box.rango_real_max)} kg"
    return {
        "box_numero": str(box.box_numero),
        "dia_salida": box.dia_salida,
        "fecha_salida": box.fecha_salida.strftime("%d/%m/%Y"),
        "fecha_recepcion": box.fecha_recepcion.strftime("%d/%m/%Y"),
        "fecha_entrada": box.fecha_entrada.strftime("%d/%m/%Y"),
        "lote": box.lote,
        "articulo_codigo": box.articulo_codigo,
        "articulo_nombre": box.articulo_nombre,
        "articulo": box.articulo_nombre,
        "total_piezas_rango": str(box.total_piezas_rango),
        "unidades": str(box.unidades),
        "dias_sal": str(box.dias_sal),
        "rango_min": format_decimal(box.rango_min),
        "rango_max": format_decimal(box.rango_max),
        "rango_peso": rango_peso,
        "rango_real": rango_real,
        "etiquetas": str(box.etiquetas),
        "pie": footer,
    }


def render_label(box: BoxEtiqueta, dpi: int = DEFAULT_DPI, template: dict | None = None) -> Image.Image:
    template = normalize_template_to_safe_area(template) if template is not None else load_label_template()
    label_width_mm, label_height_mm = label_size_from_template(template)
    width = int(label_width_mm / 25.4 * dpi)
    height = int(label_height_mm / 25.4 * dpi)
    image = Image.new("RGB", (width, height), template.get("background", "white"))
    draw = ImageDraw.Draw(image)
    base_width = int(template.get("base_width", BASE_LABEL_WIDTH) or BASE_LABEL_WIDTH)
    scale = width / base_width

    def s(value) -> int:
        return int(float(value) * scale)

    def fit_font(text: str, max_width: int, start: int, minimum: int, bold: bool = True):
        step = max(s(2), 1)
        for size in range(s(start), s(minimum) - 1, -step):
            font = _font(max(size, 1), bold)
            bbox = draw.textbbox((0, 0), text, font=font)
            if bbox[2] - bbox[0] <= max_width:
                return font
        return _font(s(minimum), bold)

    def wrap_lines(text: str, font, max_width: int) -> list[str]:
        lines: list[str] = []
        for raw_line in str(text).splitlines() or [""]:
            words = raw_line.split()
            if not words:
                lines.append("")
                continue
            current = words[0]
            for word in words[1:]:
                candidate = f"{current} {word}"
                bbox = draw.textbbox((0, 0), candidate, font=font)
                if bbox[2] - bbox[0] <= max_width:
                    current = candidate
                else:
                    lines.append(current)
                    current = word
            lines.append(current)
        return lines

    def fit_multiline_font(text: str, max_width: int, max_height: int, start: int, minimum: int, bold: bool = True, spacing: float = 1.08):
        step = max(s(2), 1)
        for size in range(s(start), s(minimum) - 1, -step):
            font = _font(max(size, 1), bold)
            lines = wrap_lines(text, font, max_width)
            line_h = max(draw.textbbox((0, 0), "Ag", font=font)[3], 1)
            if line_h * spacing * len(lines) <= max_height:
                return font, lines
        font = _font(s(minimum), bold)
        return font, wrap_lines(text, font, max_width)

    def draw_aligned_text(area: tuple[int, int, int, int], text: str, font, fill, align: str) -> None:
        if align == "center":
            _center_text(draw, area, text, font, fill=fill)
            return
        bbox = draw.textbbox((0, 0), text, font=font)
        text_w = bbox[2] - bbox[0]
        x = area[0] if align == "left" else area[2] - text_w
        draw.text((x, area[1]), text, font=font, fill=fill)

    def draw_text_block(area: tuple[int, int, int, int], text: str, font, fill, align: str, spacing: float = 1.08) -> None:
        lines = wrap_lines(text, font, max(area[2] - area[0], 1))
        line_h = max(draw.textbbox((0, 0), "Ag", font=font)[3], 1)
        y = area[1]
        for line in lines:
            if y > area[3]:
                break
            bbox = draw.textbbox((0, 0), line, font=font)
            line_w = bbox[2] - bbox[0]
            if align == "center":
                x = area[0] + ((area[2] - area[0]) - line_w) // 2
            elif align == "right":
                x = area[2] - line_w
            else:
                x = area[0]
            draw.text((x, y), line, font=font, fill=fill)
            y += int(line_h * spacing)

    values = _label_values(box)

    def resolve_text(element: dict, default: str = "") -> str:
        template_text = str(element.get("template", "")).strip()
        if template_text:
            try:
                return template_text.format_map(values)
            except Exception:
                return template_text
        key = str(element.get("key", "")).strip()
        if key:
            return values.get(key, "")
        return default

    for element in template.get("elements", []):
        if not element.get("visible", True):
            continue
        kind = element.get("type", "")
        if kind == "rect":
            x1, y1 = s(element.get("x", 0)), s(element.get("y", 0))
            x2 = x1 + s(element.get("w", 0))
            y2 = y1 + s(element.get("h", 0))
            draw.rectangle((x1, y1, x2, y2), fill=element.get("fill"), outline=element.get("outline"), width=max(s(element.get("line_width", 1)), 1))
        elif kind == "line":
            draw.line((s(element.get("x1", 0)), s(element.get("y1", 0)), s(element.get("x2", 0)), s(element.get("y2", 0))), fill=element.get("fill", "black"), width=max(s(element.get("line_width", 1)), 1))
        elif kind in {"text", "value"}:
            text = str(element.get("text", "") if kind == "text" and not element.get("template") else resolve_text(element, str(element.get("text", ""))))
            area = (s(element.get("x", 0)), s(element.get("y", 0)), s(element.get("x", 0)) + s(element.get("w", 0)), s(element.get("y", 0)) + s(element.get("h", 70)))
            if element.get("wrap", False):
                font, _lines = fit_multiline_font(text, max(area[2] - area[0], 1), max(area[3] - area[1], 1), int(element.get("font_size", 42)), int(element.get("min_size", 28)), bool(element.get("bold", True)), float(element.get("line_spacing", 1.08)))
                draw_text_block(area, text, font, element.get("fill", "black"), str(element.get("align", "left")), float(element.get("line_spacing", 1.08)))
            else:
                font = fit_font(text, max(area[2] - area[0], 1), int(element.get("font_size", 42)), int(element.get("min_size", 28)), bool(element.get("bold", True)))
                draw_aligned_text(area, text, font, element.get("fill", "black"), str(element.get("align", "left")))
        elif kind == "field":
            x, y, max_width = s(element.get("x", 0)), s(element.get("y", 0)), s(element.get("w", 100))
            label = str(element.get("label", ""))
            value = str(resolve_text(element))
            label_font = _font(s(element.get("label_size", 41)), bool(element.get("bold", True)))
            draw.text((x, y), label, font=label_font, fill=element.get("label_fill", "#373737"))
            value_y = y + s(element.get("value_offset", 52))
            value_area = (x, value_y, x + max_width, y + s(element.get("h", 180)))
            if element.get("wrap", False):
                value_font, _lines = fit_multiline_font(value, max_width, max(value_area[3] - value_area[1], 1), int(element.get("value_size", 68)), int(element.get("min_size", 42)), bool(element.get("bold", True)), float(element.get("line_spacing", 1.08)))
                draw_text_block(value_area, value, value_font, element.get("fill", "#0C0C0C"), str(element.get("align", "left")), float(element.get("line_spacing", 1.08)))
            else:
                value_font = fit_font(value, max_width, int(element.get("value_size", 68)), int(element.get("min_size", 42)), bool(element.get("bold", True)))
                draw_aligned_text(value_area, value, value_font, element.get("fill", "#0C0C0C"), str(element.get("align", "left")))
    return image.convert("L").convert("RGB")


def expand_labels(boxes: Iterable[BoxEtiqueta]) -> list[BoxEtiqueta]:
    expanded: list[BoxEtiqueta] = []
    for box in boxes:
        expanded.extend([box] * box.etiquetas)
    return expanded


def save_label_contact_sheet(boxes: Iterable[BoxEtiqueta], output_path: Path, dpi: int = 120) -> None:
    rendered = [render_label(box, dpi=dpi) for box in boxes]
    if not rendered:
        raise ValueError("No hay etiquetas que guardar.")
    cols = 2
    gap = 24
    w, h = rendered[0].size
    rows = math.ceil(len(rendered) / cols)
    sheet = Image.new("RGB", (cols * w + (cols + 1) * gap, rows * h + (rows + 1) * gap), (246, 248, 252))
    for i, img in enumerate(rendered):
        row = i // cols
        col = i % cols
        x = gap + col * (w + gap)
        y = gap + row * (h + gap)
        sheet.paste(img, (x, y))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path)


def list_windows_printers() -> list[str]:
    try:
        import win32print
    except Exception:
        return []
    flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
    return [printer[2] for printer in win32print.EnumPrinters(flags)]


def default_windows_printer() -> str:
    try:
        import win32print
        return win32print.GetDefaultPrinter()
    except Exception:
        return ""


def print_labels_windows(boxes: Iterable[BoxEtiqueta], printer_name: str | None = None, template: dict | None = None) -> int:
    try:
        import win32con
        import win32ui
        from PIL import ImageWin
    except Exception as exc:
        raise RuntimeError("La impresion directa requiere pywin32 instalado.") from exc

    labels = expand_labels(boxes)
    if not labels:
        raise ValueError("No hay etiquetas que imprimir.")

    printer = printer_name or default_windows_printer()
    if not printer:
        raise ValueError("No hay impresora Windows seleccionada.")

    hdc = win32ui.CreateDC()
    hdc.CreatePrinterDC(printer)
    printable_width = hdc.GetDeviceCaps(win32con.HORZRES)
    printable_height = hdc.GetDeviceCaps(win32con.VERTRES)
    physical_width = hdc.GetDeviceCaps(win32con.PHYSICALWIDTH) or printable_width
    physical_height = hdc.GetDeviceCaps(win32con.PHYSICALHEIGHT) or printable_height
    offset_x = hdc.GetDeviceCaps(win32con.PHYSICALOFFSETX)
    offset_y = hdc.GetDeviceCaps(win32con.PHYSICALOFFSETY)
    dpi_x = max(hdc.GetDeviceCaps(win32con.LOGPIXELSX), 1)
    dpi_y = max(hdc.GetDeviceCaps(win32con.LOGPIXELSY), 1)

    hdc.StartDoc("Etiquetas boxes salazon")
    try:
        for box in labels:
            img = render_label(box, dpi=DEFAULT_DPI, template=template).convert("RGB")
            left, top, right, bottom = calculate_centered_print_rect(
                physical_width,
                physical_height,
                printable_width,
                printable_height,
                offset_x,
                offset_y,
                dpi_x,
                dpi_y,
                img.width,
                img.height,
            )
            dib = ImageWin.Dib(img)
            hdc.StartPage()
            dib.draw(hdc.GetHandleOutput(), (left, top, right, bottom))
            hdc.EndPage()
    finally:
        hdc.EndDoc()
        hdc.DeleteDC()
    return len(labels)






