@echo off
chcp 65001 >nul
setlocal EnableExtensions

set "APP_NAME=Etiquetado_Box_Salazon"
set "APP_TITLE=Etiquetado Box Salazon"
set "SOURCE_DIR=%~dp0%APP_NAME%"
set "DEST_DIR=%ProgramFiles%\Etiquetado Box Salazon"
set "DESKTOP_LINK=%Public%\Desktop\%APP_TITLE%.lnk"

echo.
echo ============================================================
echo  INSTALAR ETIQUETADO BOX SALAZON
echo ============================================================
echo.

net session >nul 2>nul
if errorlevel 1 (
    echo ERROR: Ejecuta este instalador como administrador.
    echo.
    echo Clic derecho sobre este BAT ^> Ejecutar como administrador
    echo.
    pause
    exit /b 1
)

if not exist "%SOURCE_DIR%\%APP_NAME%.exe" (
    echo ERROR: No se encuentra "%SOURCE_DIR%\%APP_NAME%.exe".
    echo Este BAT debe estar junto a la carpeta "%APP_NAME%" generada para el USB.
    pause
    exit /b 1
)

echo Copiando aplicacion a:
echo "%DEST_DIR%"
if not exist "%DEST_DIR%" mkdir "%DEST_DIR%"
robocopy "%SOURCE_DIR%" "%DEST_DIR%" /E /NFL /NDL /NJH /NJS /NP
if errorlevel 8 (
    echo ERROR: No se pudo copiar la aplicacion.
    pause
    exit /b 1
)

echo.
echo Preparando datos dentro de la carpeta de instalacion...
if not exist "%DEST_DIR%\exportaciones" mkdir "%DEST_DIR%\exportaciones"
if not exist "%DEST_DIR%\config" (
    if exist "%DEST_DIR%\_internal\config" robocopy "%DEST_DIR%\_internal\config" "%DEST_DIR%\config" /E /NFL /NDL /NJH /NJS /NP >nul
)
icacls "%DEST_DIR%" /grant *S-1-5-32-545:^(OI^)^(CI^)M /T >nul

echo.
echo Creando acceso directo en el escritorio publico...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$shortcut=(New-Object -ComObject WScript.Shell).CreateShortcut('%DESKTOP_LINK%'); $shortcut.TargetPath='%DEST_DIR%\%APP_NAME%.exe'; $shortcut.WorkingDirectory='%DEST_DIR%'; $shortcut.IconLocation='%DEST_DIR%\%APP_NAME%.exe,0'; $shortcut.Save()"
if errorlevel 1 (
    echo AVISO: No se pudo crear el acceso directo del escritorio.
) else (
    echo Acceso directo creado.
)

echo.
echo ============================================================
echo  INSTALACION COMPLETADA
echo ============================================================
echo.
echo Puedes abrir la aplicacion desde el escritorio:
echo %APP_TITLE%
echo.
echo Recuerda instalar/configurar la impresora Citizen CL-S703 en Windows.
echo.
pause
exit /b 0
